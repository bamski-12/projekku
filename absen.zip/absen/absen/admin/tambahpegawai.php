<h2>Tambah Pegawai</h2>

<form method="POST" enctype="multipart/form-data">
<div class="form-group">
        <label> nip </label>
        <input type="text" class="form-control" name="nip">
</div>
<div class="form-group">
        <label> nama </label>
        <input type="text" class="form-control" name="nama">
</div>
<div class="form-group">
        <label> foto </label>
        <input type="file" class="form-control" name="foto">
</div>
<div class="form-group">
        <label> divisi </label>
        <input type="text" class="form-control" name="divisi" >
</div>
<div class="form-group">
        <label> jabatan </label>
        <input type="text" class="form-control" name="jabatan" >
</div>

<button class="btn btn-primary" name="save">simpan</button>
</form>
<?php
if (isset($_POST['save']))
{
        $nama = $_FILES['foto']['name'];
        $lokasi = $_FILES['foto']['tmp_name'];
        move_uploaded_file($lokasi,"../images/".$nama);
        $koneksi->query("INSERT INTO tb_peg (nip,nama,foto,divisi,jabatan)
        VALUES ('$_POST[nip]','$_POST[nama]','$nama','$_POST[divisi]','$_POST[jabatan]')");

        echo "<div class='alert alert-info'>Data Tersimpan </div>";
        echo "<meta http-equiv='refresh' content='l;url=index.php?halaman=pegawai'>";
}
?>
