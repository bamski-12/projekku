<h2>Ubah pelanggan</h2>

<?php

$ambil = $koneksi->query("SELECT * FROM pelanggan WHERE id_pelanggan='$_GET[id]'");
$data = $ambil->fetch_assoc();

echo "<pre>";
print_r($data);
echo "</pre>";
?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
    <label>nama  </label>
    <input type="text" name="nama" class="form-control" value="<?php echo $data['nama'];?>">
    </div>
    <div class="form-group">
    <label>email </label>
    <input type="text" name="email" class="form-control" value="<?php echo $data['email'];?>">
    </div>
    <div class="form-group">
    <label>Password</label>
    <input type="password" name="pass" class="form-control" value="<?php echo $data['pass'];?>">
    </div>
    <div class="form-group">
    <label>alamat </label>
    <textarea  name="alamat" class="form-control" rows="10">
    <?php echo $data['alamat'];?></textarea>
    </div>
    <div class="form-group">
    <label>nomer handphone</label>
    <input type="text" name="no_hp" class="form-control" value="<?php echo $data['no_hp'];?>">
    </div>
    <button class="btn btn-primary" name=ubah>Ubah</button>
</form>
<?php
if (isset($_POST['ubah']))
{
    $koneksi->query("UPDATE pelanggan SET nama='$_POST[nama]',email='$_POST[email]',
    pass='$_POST[pass]',alamat='$_POST[alamat]',no_hp='$_POST[no_hp]' WHERE id_pelanggan='$_GET[id]'");


echo "<script>alert('data pelanggan telah dirubah');</script>";
echo "<script>location='index.php?halaman=pelanggan';</script>";
}
?>