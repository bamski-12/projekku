<h2>Tambah Admin</h2>

<form method="POST" enctype="multipart/form-data">
<div class="form-group">
        <label> username </label>
        <input type="text" class="form-control" name="username">
</div>
<div class="form-group">
        <label> password </label>
        <input type="password" class="form-control" name="password">
</div>

<button class="btn btn-primary" name="save">simpan</button>
</form>
<?php
if (isset($_POST['save']))
{
        
        $koneksi->query("INSERT INTO admin(username,password)
        VALUES ('$_POST[username]','$_POST[password]')");

        echo "<div class='alert alert-info'>Data Tersimpan </div>";
        echo "<meta http-equiv='refresh' content='l;url=index.php?halaman=dataadmin'>";
}
?>
