<h2>Ubah Admin</h2>

<?php

$ambil = $koneksi->query("SELECT * FROM admin WHERE id_admin='$_GET[id]'");
$data = $ambil->fetch_assoc();


?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
    <label>username </label>
    <input type="text" name="username" class="form-control" value="<?php echo $data['username'];?>">
    </div>
    <div class="form-group">
    <label>password </label>
    <input type="text" name="password" class="form-control" value="<?php echo $data['password'];?>">
    </div>
    
    <button class="btn btn-primary" name=ubah>Ubah</button>
</form>

<?php
if (isset($_POST['ubah']))
{
    $koneksi->query("UPDATE admin SET username='$_POST[username]',password='$_POST[password]' WHERE id_admin='$_GET[id]'");


echo "<script>alert('data admin telah dirubah');</script>";
echo "<script>location='index.php?halaman=dataadmin';</script>";
}
?>

