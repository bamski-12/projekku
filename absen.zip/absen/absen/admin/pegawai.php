<h2>Pegawai</h2>

<div class="row">
    <div class="col-md-12">
    <!-- Advanced Tables -->
    <div class="panel panel-default">
    <div class="panel-heading">
        Daftar Pegawai Perusahaan
        </div>
        <div class="panel-body">
            <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr>
                    <th>no</th>
					<th>nip</th>
					<th>nama</th>
					<th>divisi</th>
					<th>jabatan</th>
					<th>foto</th>
					<th>aksi</th>
                    </tr>
                </thead>
               <?php $nomor=1;?>
               <?php 
                     $ambil = $koneksi->query("SELECT * FROM tb_peg");?>
					<?php while ($data = $ambil->fetch_assoc()) {?>
               <tbody>
                        
                    <td><?php echo $nomor; ?></td>
					<td><?php echo $data['nip']; ?></td>
					<td><?php echo $data['nama']; ?></td>
					<td><?php echo $data['divisi']; ?></td>
					 <td><?php echo $data['jabatan']; ?></td>
					 <td><img src="../images/<?php echo $data['gambar']; ?>" width="100"></td>
					<td><a href="index.php?halaman=hapuspegawai&id=<?php echo $data['nip'];?>" class="btn-danger btn">hapus</a>
					<a href="index.php?halaman=ubahpegawai&id=<?php echo $data['nip'];?>" class="btn-warning btn">ubah</a></td>
					<?php $nomor++;?>
					<?php }?>
               </tbody>
           </table>




    <a href="index.php?halaman=tambahpegawai" class="btn btn-primary"> Tambah Data </a>