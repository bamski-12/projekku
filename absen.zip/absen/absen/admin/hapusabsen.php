<?php

$ambil = $koneksi->query("SELECT * FROM tb_absen WHERE id_absen='$_GET[id]'");
$data = $ambil->fetch_assoc();

$koneksi->query("DELETE FROM tb_absen WHERE id_absen='$_GET[id]'");

echo "<script>alert('absen telah dihapus');</script>";
echo "<script>location='index.php?halaman=absen';</script>";

?>