<h2>Ubah Pegawai</h2>


<?php

$ambil = $koneksi->query("SELECT * FROM tb_peg WHERE nip='$_GET[id]'");
$data = $ambil->fetch_assoc();

?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
    <label>nip </label>
    <input type="text" name="nip" class="form-control" value="<?php echo $data['nip'];?>">
    </div>
    <div class="form-group">
    <label>nama </label>
    <input type="text" name="nama" class="form-control" value="<?php echo $data['nama'];?>">
    </div>
	 <div class="form-group">
    <label>divisi </label>
    <input type="text" name="divisi" class="form-control" value="<?php echo $data['divisi'];?>">
    </div>
	 <div class="form-group">
    <label>jabatan </label>
    <input type="text" name="jabatan" class="form-control" value="<?php echo $data['jabatan'];?>">
    </div>
	 <div class="form-group">
    <img src="../image/<?php echo $data['gambar']?>" width="200">
    </div>
    <div class="form-group">
    <label>ganti foto</label>
    <input type="file" name="foto" class="form-control">
    </div>
    
    <button class="btn btn-primary" name=ubah>Ubah</button>
</form>

<?php
if (isset($_POST['ubah']))
{
    $namafoto=$_FILES['foto']['name'];
    $lokasifoto = $_FILES['foto']['tmp_name'];

    if (!empty($lokasifoto))
    {
        move_uploaded_file($lokasifoto, "../images/$namafoto");

        $koneksi->query("UPDATE tb_peg SET nip='$_POST[nip]',nama='$_POST[nama]',divisi='$_POST[divisi]',
        jabatan='$_POST[jabatan]',gambar='$namafoto' WHERE id_pegawai='$_GET[id]'");

    }
    else
    {
        $koneksi->query("UPDATE tb_peg SET nip='$_POST[nip]',nama='$_POST[nama]',divisi='$_POST[divisi]',
        jabatan='$_POST[jabatan]' WHERE id_pegawai='$_GET[id]'");
   
    }
    echo "<script>alert('data pegawai telah dirubah');</script>";
    echo "<script>location='index.php?halaman=pegawai';</script>";
}
?>