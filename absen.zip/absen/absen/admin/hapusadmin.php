<?php

$ambil = $koneksi->query("SELECT * FROM admin WHERE id_admin='$_GET[id]'");
$data = $ambil->fetch_assoc();

$koneksi->query("DELETE FROM admin WHERE id_admin='$_GET[id]'");

echo "<script>alert('admin telah terhapus');</script>";
echo "<script>location='index.php?halaman=dataadmin';</script>";

?>