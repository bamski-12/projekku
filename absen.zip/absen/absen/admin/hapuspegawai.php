<?php

$ambil = $koneksi->query("SELECT * FROM tb_peg WHERE nip='$_GET[id]'");
$data = $ambil->fetch_assoc();
$koneksi->query("DELETE FROM tb_peg WHERE nip='$_GET[id]'");

echo "<script>alert('pegawai telah terhapus');</script>";
echo "<script>location='index.php?halaman=pegawai';</script>";

?>