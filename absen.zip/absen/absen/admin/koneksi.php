<?php 
$koneksi = mysqli_connect("localhost","root","","latian");

?>