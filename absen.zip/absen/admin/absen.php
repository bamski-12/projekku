<h2>Absen Pegawai</h2>
<div class="row">
    <div class="col-md-12">
    <!-- Advanced Tables -->
    <div class="panel panel-default">
    <div class="panel-heading">
        Daftar Absen Pegawai
        </div>
        <div class="panel-body">
            <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr>
                    <th>No</th>
                    <th>NIP</th>
                    <th>Nama</th>
					<th>Gambar</th>
                    <th>Divisi</th>
                    <th>Jabatan</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
               <?php $nomor=1;?>
               <?php 
                     $ambil = $koneksi->query("SELECT * FROM tb_absen INNER JOIN tb_peg ON 
                     tb_peg.nip = tb_absen.nip");?>
                     <?php while ($data = $ambil->fetch_assoc()) {?>
               <tbody>
                        
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data['nip']; ?></td>
                    <td><?php echo $data['nama']; ?></td>
					<td><?php echo $data['foto']; ?></td>
                    <td><?php echo $data['divisi']; ?></td>
                    <td><?php echo $data['jabatan']; ?></td>
                    <td><?php echo $data['tgl']; ?></td>
                    <td><?php echo $data['jam']; ?></td>
                    <td><a href="index.php?halaman=hapusabsen&id=<?php echo $data['id_absen'];?>" class="btn-danger btn">hapus</a>
                        </td>
                    <?php $nomor++; ?>
               <?php }?>
               </tbody>
           </table>